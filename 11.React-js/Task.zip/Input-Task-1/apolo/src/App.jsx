import "./App.css";
import UseRefExample from "./component/InputTask-1";
import ImageScroll from "./component/ImageScroll-2";
import VideoPlayer from "./component/VedioTask-3";
import ExposeRefExample from "./component/Exposing-ref-4";
import ClickCounter from "./component/Counter-5";
import Stopwatch from "./component/Stopwatch-6";
import ShopPage from "./component/ProductPage";

function App(){
  return (
    <>
    {/* <UseRefExample/> */}
    {/* <ImageScroll/> */}
    {/* <VideoPlayer/> */}
    {/* <ExposeRefExample/> */}
    {/* <ClickCounter/> */}
    {/* <Stopwatch/> */}
    <ShopPage/>
    </>
  )
}

export default App;
