import React from 'react'

const AboutPage = () => {
  return (
    <div>This is AboutPage</div>
  )
}

export default AboutPage